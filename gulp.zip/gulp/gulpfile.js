var gulp = require('gulp');

gulp.task('task1', function () {
	console.log('gulp!!!!!!!!!!!!');
});

gulp.task('task2', function () {
	alert("Алерт, созданный с помощью Gulp");
});

exports.build = series(task2);